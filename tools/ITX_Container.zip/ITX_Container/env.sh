#!/usr/bin/bash
## Locate your APIKEY (Entitlement Key For Container Software) 
## here: https://myibm.ibm.com/products-services/containerlibrary
## Requires IBM ID and permission.
export PROJECT_NAME="itxrs"
export PROJECT_DIR="$HOME/itxrs"
export APIKEY=""
