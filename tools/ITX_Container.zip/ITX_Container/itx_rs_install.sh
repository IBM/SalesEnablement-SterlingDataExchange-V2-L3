#!/usr/bin/bash
## Exit if there is an error
set -e

# Set OCP default storage class
oc patch storageclass ocs-storagecluster-cephfs -p '{"metadata": {"annotations": {"storageclass.kubernetes.io/is-default-class": "true"}}}'

## To read env.sh file.
source $(dirname $(realpath ${0}))/env.sh
if [ -z "$APIKEY" ] ; then
  echo "You must provide entitlement key in the env.sh file."
  exit 1
fi
## 
#Uninstall 
cat <<\EOF > delete_itx.sh
helm delete ${PROJECT_NAME}
oc delete -f itx_scc.yaml
oc delete secret ibm-entitlement-key
oc delete PodSecurityPolicy ibm-itx-rs-scc
oc delete project ${PROJECT_NAME}
rm *.tgz
EOF
chmod 755 delete_itx.sh
#./delete_itx.sh
sleep 10s
## Create new project for B2Bi reading project name from env.sh

oc new-project ${PROJECT_NAME}

## Create entitlement secret.
cat <<\EOF > entitledregistry.sh
#!/bin/bash
## To read env.sh file.
source $(dirname $(realpath ${0}))/env.sh
oc create secret docker-registry ibm-entitlement-key \
--docker-username=cp \
--docker-password=${APIKEY} \
--docker-email=${EMAIL} \
--docker-server=cp.icr.io -n ${PROJECT_NAME}
EOF
## Read api token from env.sh file for entitlement of certified containers.
chmod 755 entitledregistry.sh ; ./entitledregistry.sh

# Applying SecurityContextConstraints
cat << EOF > itx_scc.yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy allows a single, non-root user"
  name: ibm-itx-rs-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: []
allowedFlexVolumes: []
defaultAddCapabilities: []
defaultPrivilegeEscalation: false
forbiddenSysctls:
   - "*"
fsGroup:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
  uidRangeMin: 1000
  uidRangeMax: 65535
seccompProfiles:
- docker/default
seLinuxContext:
  type: RunAsAny
supplementalGroups:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
priority: 0
EOF
envsubst < itx_scc.yaml | oc apply -f -

#Create the constraint.
oc apply -f itx_scc.yaml -n ${PROJECT_NAME}

#Apply the constraint.
#oc adm policy add-scc-to-group ibm-itx-rs-scc system:serviceaccounts:itx-container-icr
oc adm policy add-scc-to-group ibm-itx-rs-scc system:serviceaccounts:${PROJECT_NAME}

# Download/extract Helm Chart version 2.0.5 (latest as of the writing)
wget https://github.com/IBM/charts/raw/master/repo/ibm-helm/itx-rs-prod-2.0.0.tgz
tar -xvf itx-rs-prod-2.0.0.tgz
## Deploy Helm chart.
#helm install ${PROJECT_NAME} itx-rs-prod --timeout 120m0s --set license.accept=true -f itx-rs-prod/values.yaml
helm install ${PROJECT_NAME} --timeout 120m0s --set license.accept=true  --set map.fileExtension=mmc -f itx-rs-prod/values.yaml itx-rs-prod-2.0.0.tgz

#sleep 4m

#Deploy sample map to verify itx install
## Identify pod name.
export ITX_RS_POD=$(oc get po | grep itx-rs | awk {'print $1'})
## Setup storage directories and copy the jar file. Wait a minute.
oc cp samples/OneInOneOut.lnx $ITX_RS_POD:/data/maps
oc rsh pod/${ITX_RS_POD} cp /data/maps/OneInOneOut.lnx /data/maps/OneInOneOut.mmc

sleep 10s

#To test:
export ITX_RS_ROUTE=$(oc get route itx-rs-route |grep itx-rs | awk {'print $2'})
curl -X PUT -d "This is a Test" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/OneInOneOut?input=1&output=1"

