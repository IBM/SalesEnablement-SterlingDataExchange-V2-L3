#!/usr/bin/bash

## Exit if there is an error
set -e
source $(dirname $(realpath ${0}))/env.sh
oc project ${PROJECT_NAME}
## Identify pod name.
export ITX_RS_ROUTE=$(oc get route itx-rs-route |grep itx-rs | awk {'print $2'})
export ITX_RS_POD=$(oc get po | grep itx-rs | awk {'print $1'})

# Deploy maps
# To transfer fhir maps to container. Fhir maps will be copied to container /data/maps/fhir folder.
oc rsync samples/maps/fhir $ITX_RS_POD:/data/maps

# To transfer fhir input data to container under /data/input/fhir folder. (optional)
oc rsync samples/input/fhir $ITX_RS_POD:/data/input

# Deploy hl7 and ncpdp maps
oc rsync samples/maps/hl7_ncpdp $ITX_RS_POD:/data/maps
oc rsync samples/input/hl7_ncpdp $ITX_RS_POD:/data/input

#Copy one file to container:
#curl -f -F "data=@samples/FHIR/maps/fhir_pas_to_278.mmc" "$ITX_RS_ROUTE/itx-rs/v1/data/maps"
#curl -f -F "data=@samples/FHIR/data/Bundle-ReferralAuthorizationBundleExample.json" "$ITX_RS_ROUTE/itx-rs/v1/data/input"

# Run the maps

#Use case 1: Prior authorization round trip.
#  1.1. Requester produces prior authorization request in fhir json format, translates to x12 278 request, and then sends to insurer; 
#  1.2. Insurer recieves 278 request, determins whether to approve or reject, and then sends x12 278 response (approval or reject) back to requester.
#  1.3  Requester receives 278 response and translate to fhir json xml format.
# Three maps were built. 
#  1. fhir_pas_to_278 takes pas json bundle and translate it to 278 request. 
#  2. 278req_to_response takes the 278 and translate it to 278 response, simulating Payer process.
#  3. 278_to_fhir_pas takes the 278 response and translate it to fhir json.
#  Map 2 and map 3 were built into map 1, to make invocation easier. 
# Commands to call:
#  1. FHIR PAS (prior authorization support) bundle to x12 278 request: 
#     Option 1 - Use the input file already in container
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/fhir_pas_to_278?input=1;FILE;/data/input/fhir/Bundle-ReferralAuthorizationBundleExample.json&output=1"
#     Option 2 - Use input file from client
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/fhir/Bundle-ReferralAuthorizationBundleExample.json" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/fhir_pas_to_278?output=1"
#  2. Use "output=2" to return 278 response. 
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/fhir_pas_to_278?input=1;FILE;/data/input/fhir/Bundle-ReferralAuthorizationBundleExample.json&output=2"
#  3. Use "output=3" to return fhir json response.
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/fhir_pas_to_278?input=1;FILE;/data/input/fhir/Bundle-ReferralAuthorizationBundleExample.json&output=3"

#Use case 2: Call pas_fhir_to_x12 map to transfer FHIR PAS (prior authorization support) bundle in XML format to x12 278 and 275 transacions
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/pas_fhir_to_x12?input=1;FILE;/data/input/fhir/bundle.xml&output=1"

#Use case 3: call observation_json map to transfer hl7 oru (obeservation) to FHIR JSON format
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/observation_json?input=1;FILE;/data/input/fhir/sample_hl7_edi_oru.dat&input=2;FILE;/data/input/fhir/codesystem_lookup.txt&output=1"

#Use case 4: call observation_json map to transfer hl7 oru (obeservation) to FHIR XML format
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/fhir/observation_xml?input=1;FILE;/data/input/fhir/sample_hl7_edi_oru.dat&input=2;FILE;/data/input/fhir/codesystem_lookup.txt&output=1"

#Use case 5: call ncpdp_script_to_hl7 map to transfer ncpdp script to hl7 output
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hl7_ncpdp/ncpdp_script_to_hl7?input=1;FILE;/data/input/hl7_ncpdp/ncpdp_input.dat&output=1"

#Use case 6: call hl7_to_ncpdp_script map to transfer hl7 input to ncpdp script
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hl7_ncpdp/hl7_to_ncpdp_script?input=1;FILE;/data/input/hl7_ncpdp/hl7_input.dat&output=1"

# To debug, use return=trace
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hl7_ncpdp/ncpdp_script_to_hl7?input=1;FILE;/data/input/hl7_ncpdp/ncpdp_input.dat&return=trace"
