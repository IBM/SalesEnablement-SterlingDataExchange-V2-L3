#!/usr/bin/bash

## Exit if there is an error
set -e

## Identify pod name.
export ITX_RS_POD=$(oc get po | grep itx-rs | awk {'print $1'})
export ITX_RS_ROUTE=$(oc get route itx-rs-route |grep itx-rs | awk {'print $2'})

#Deploy HIPAA compliance maps and test data:
#Transfer hipaa.zip file and have it unzip in the container. This creates hipaa/maps and hipaa/data directories under /data/maps in ITX container
curl -F "data=@samples/hipaa.zip" -H "rs-action: unpack" "http://${ITX_RS_ROUTE}/itx-rs/v1/data/maps"


# Run Compliance check map:

# Output1: Generate Compliance_Check_Results
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=1" > samples/output/compliancecheck/output1.txt

curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=2" > samples/output/compliancecheck/output2.xml

#Output 6: good transactions. Compliance check map seperates the good transactions from bad ones. 
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=6" > samples/output/compliancecheck/good.dat

#Output 7: bad transactions.
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=7" > samples/output/compliancecheck/bad.dat

#Output 9: 999 Ack.
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=9" > samples/output/compliancecheck/Ack.txt

#Output 10: Compliance report html
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=10" > samples/output/compliancecheck/compliance_report.html

#Output 11: TAck_EDI.html
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=11" > samples/output/compliancecheck/TAck_EDI.html

#Output 13: report
curl -X PUT -H "Content-Type: multipart/form-data" -F "2=@samples/input/compliancecheck/837i_5010a2_examples--bad.dat" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/hipaa/maps/hipaa_data_compliance?output=13" > samples/output/compliancecheck/report.json
