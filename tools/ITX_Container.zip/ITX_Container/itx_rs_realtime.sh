#!/usr/bin/bash

## Exit if there is an error
set -e
source $(dirname $(realpath ${0}))/env.sh
#oc project ${PROJECT_NAME}
## Identify pod name.
export ITX_RS_ROUTE=$(oc get route itx-rs-route |grep itx-rs | awk {'print $2'})
export ITX_RS_POD=$(oc get po | grep itx-rs | awk {'print $1'})

# To transfer 270 files to container
#curl -f -F "data=@samples/Realtime/maps/270To271.mmc" "http://${ITX_RS_ROUTE}/itx-rs/v1/data/maps"
#oc cp Realtime/270To271.mmc ${ITX_RS_POD}:/data/maps/270To271.lnx

#oc rsh pod/${ITX_RS_POD} mkdir /data/input
oc rsync samples/maps/realtime $ITX_RS_POD:/data/maps
oc rsync samples/input/realtime $ITX_RS_POD:/data/input
#curl -F "data=@samples/data.zip" -H "rs-action: unpack" "http://${ITX_RS_ROUTE}/itx-rs/v1/data/input"

# Run the 270To271 map
#Option 1: Use the input data that have been transferred to OpenShift.
curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?input=1;FILE;/data/input/realtime/X12_270_In.txt_JT&output=4"
curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?input=1;FILE;/data/input/realtime/X12_270_In.txt_RC&output=4"
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?input=1;FILE;/data/input/realtime/X12_270_In.txt_INVALID_NAME&output=4"
#curl -X PUT -d "" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?input=1;FILE;/data/input/realtime/X12_270_In.txt_INVALID_X12&output=4"

#Option 2: Use the input data from the client.
curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/X12_270_In.txt_RC" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?output=4"
curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/X12_270_In.txt_JT" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?output=4"
curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/X12_270_In.txt_INVALID_X12" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?output=4"
curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/X12_270_In.txt_INVALID_NAME" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271?output=4"

# Run the 270To271 WSDL map
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/270Data_RC.txt" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271_WSDL?output=4"
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/270Data_JT.txt" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271_WSDL?output=4"
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/270Data_JPM.txt" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271_WSDL?output=4"
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/input/realtime/270Data_Invalid_X12.txt"  "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271_WSDL?output=4"
#curl -X PUT -H "Content-Type: multipart/form-data" -F "1=@samples/270Data_Invalid_Name.txt" "${ITX_RS_ROUTE}/itx-rs/v1/maps/direct/realtime/270To271_WSDL?output=4"
